# Final-React-Native -- Filmes & Series


Grupo 5:

Hugo Braga,

Thamires Esteves,

Lucas Rispoli,

Mateus dos Santos,

Maxwel Robson
